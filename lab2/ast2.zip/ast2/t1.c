ggg(){
int y,y1;
y=4;
y1=6+y;

y=(y1*8)-(9+8);
}

