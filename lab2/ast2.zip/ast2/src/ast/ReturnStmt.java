package ast;

public class ReturnStmt extends Node {

	public ReturnStmt(int p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ReturnStmt []";
	}

}
