package ast;

public class Register {

	String name;

	public Register(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Register [name=" + name + "]";
	}
	

}
